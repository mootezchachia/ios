require('./config/db')
require("dotenv").config()


// DEPENDENCIES
const express = require("express")

// VARIABLES
const app = express();
const port = process.env.PORT

// MIDDLEWARES
app.use(express.json())
app.use(express.static('public'))
app.use('/img', express.static('uploads/images'))



// ROUTES
app.use("/user", require("./routes/user-route"))
app.use("/post", require("./routes/post-route"))
app.use("/item", require("./routes/item-route"))
app.use("/chat", require("./routes/chat-route"))
app.use("/like", require("./routes/like-route"))
app.use("/comment", require("./routes/comment-route"))


// SERVER START
app.listen(port, () => console.log(`Server up and running on port ${port} !`))
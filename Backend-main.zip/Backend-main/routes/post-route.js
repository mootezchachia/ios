const express = require("express")
const router = express.Router()
const PostController = require("../controllers/post-controller")
const upload = require('../config/storage-images')

router.route("/")
  .get(PostController.getAll)
  .post(/*upload.single('image'), */PostController.add)
  .put(PostController.edit)
  .delete(PostController.delete)

router.route("/my").post(PostController.getMy)
router.delete("/all", PostController.deleteAll)

module.exports = router
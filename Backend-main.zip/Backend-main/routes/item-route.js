const express = require("express")
const router = express.Router()
const ItemController = require("../controllers/item-controller")
const upload = require('../config/storage-images')

router.route("/")
  .get(ItemController.getAll)
  .post(upload.single('image'),ItemController.add)
  .put(ItemController.edit)
  .delete(ItemController.delete)

router.route("/my").post(ItemController.getMy)
router.delete("/all", ItemController.deleteAll)

module.exports = router
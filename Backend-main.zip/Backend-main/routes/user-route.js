const express = require("express")
const router = express.Router()
const userController = require("../controllers/user-controller")
const {verifyEmail} = require ('../config/JWT')
const {LoginAuth} = require ('../config/JWT')


router.route("/").get(LoginAuth,userController.getAll)
router.route("/all").delete(LoginAuth,userController.deleteAll);

router.post("/register", userController.register);
router.post("/login",verifyEmail, userController.login);
router.get("/verify-email",userController.verify);
router.post("/forgot-password", userController.forgotPassword);
router.put("/update-profile",LoginAuth, userController.updateProfile);
router.get("/update-password", userController.updatePassword);

router.get("/logout",LoginAuth,userController.logout);

router.route("/one")
    .get(LoginAuth,userController.get)
    .delete(LoginAuth,userController.delete);



module.exports = router
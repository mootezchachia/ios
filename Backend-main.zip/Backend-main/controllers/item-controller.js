let Item = require("../models/item")
const fs = require("fs")

exports.getAll = async (req, res) => {
  res.send({ items: await Item.find() })
}

exports.getMy = async (req, res) => {
  res.send({ items: await Item.find({ user: req.body.user }) })
}

exports.add = async (req, res) => {
  const { title, description,price, userId } = req.body

  let imageFilename;
  if (req.file) {
    imageFilename = req.file.filename
  }

  let item = await new Item({
    title,
    description,
    price,
    imageFilename,
    userId,
  }).save()

  return res.status(200).send({ message: "item added successfully", item });
}

exports.edit = async (req, res) => {
  const { _id, title, description,price,imageFilename } = req.body
  let item = await Item.findOneAndUpdate(
    { _id: _id },
    {
      $set: {
        title,
        price,
        description,
        imageFilename
      },
    }
  )

  res.status(200).send({ message: "Item edited successfully", item })
}

exports.delete = async (req, res) => {
  await Item.findById(req.body._id)
    .then(function (item) {

      deleteFile("./uploads/images/" + item.imageFilename)
      item.remove()

      res.status(200).send({ message: "item deleted successfully" })
    })
    .catch(function (error) {
      console.log(error)
      res.status(500).send({ error })
    })
}

exports.deleteAll = async (_req, res) => {
  await Item.find({})
    .then(function (items) {
        items.forEach(function (item) {

        deleteFile("./uploads/images/" + item.imageFilename)
        item.remove()

        res.status(200).send({ message: "All items have been deleted" })
      })
        .catch(function (error) {
          res.status(500).send(error)
        })
    })
}

function deleteFile(fullPath) {
  fs.unlink(fullPath, (err) => {
    if (err) {
      console.error("Could not delete file " + fullPath + " : " + err);
      return;
    }
  });
}
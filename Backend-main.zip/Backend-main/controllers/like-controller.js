const Like = require("../models/Like")
const Post = require("../models/Post")

exports.addOuSupprimer = async (req, res) => {
  const { idUser, idPost } = req.body

  let like = await Like.findOne({
    user: idUser,
    post: idPost,
  })
  let post = await Post.findById(idPost)

  if (like) {
    post.update(
      { _id: user },
      {
        $pull: {
          likes: [like._id],
        },
      }
    )

    like.remove()
  } else {
    like = new Like()
    like.date = Date.now()
    like.user = idUser
    like.post = idPost

    post.update(
        { _id: user },
        {
          $push: {
            likes: [like._id],
          },
        }
      )

    like.save()
  }

  res.status(200).send({ message: "success" })
}
